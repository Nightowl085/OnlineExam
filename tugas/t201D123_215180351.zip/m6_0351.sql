-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2017 at 03:04 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `m6_0351`
--
CREATE DATABASE IF NOT EXISTS `m6_0351` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `m6_0351`;

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

DROP TABLE IF EXISTS `barang`;
CREATE TABLE `barang` (
  `kode` varchar(11) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `harga` varchar(20) NOT NULL,
  `stok` int(10) NOT NULL,
  `ukuran` varchar(100) NOT NULL,
  `lokasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kode`, `nama`, `harga`, `stok`, `ukuran`, `lokasi`) VALUES
('BAO001', 'Adidas Originals Superstar Sneakers', '169.99', 12, '38,39,40,41', 'BAO001.jpg'),
('BCA001', 'Cinq a Sept Octavia Dress', '595', 9, 'S,M,L,XL', 'BCA001.jpg'),
('BCO001', 'Citizens of Humanity The Principle Girlfriend Jeans', '198', 12, 'S,M,L,XL', 'BCO001.jpg'),
('BCP001', 'Celine Powder with Black Handles Luggage Tote Bag', '245', 12, '', 'BCP001.jpg'),
('BFB001', 'Freebird by Steven Phoenix Low Dress ', '250', 10, 'S,M,L,XL', 'BFB001.jpg'),
('BIR001', 'Indigo Rd. Boots', '68.95', 12, '38,39,40,41', 'BIR001.jpg'),
('BKS001', 'Kate Spade New York Bow Tie Crepe A-Line Dress', '20.20', 10, 'S,M,L,XL', 'BKS001.jpg'),
('BLB001', 'Lace Blouse', '24.99', 10, 'S,M,L,XL', 'BLB001.jpg'),
('BUA001', 'UGG Australia Womenâ€™s Bailey Button Boots', '165', 10, '38,39,40,41', 'BUA001.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE `transaksi` (
  `transkode` int(5) NOT NULL,
  `username` varchar(100) NOT NULL,
  `kode` varchar(6) NOT NULL,
  `jumlah` varchar(100) NOT NULL,
  `uk` varchar(5) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`transkode`, `username`, `kode`, `jumlah`, `uk`, `status`) VALUES
(1, 'benyamin', 'BKS001', '2', 'S', 1),
(2, 'benyamin', 'BKS001', '2', 'S', 1),
(3, 'benyamin', 'BAO001', '2', '38', 1),
(3, 'benyamin', 'BCA001', '1', 'S', 1),
(4, 'benyamin', 'BAO001', '1', '38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `telepon` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table User yang digunakan untuk login';

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `nama`, `telepon`) VALUES
('admin', 'admin', 'Administrator', '0313551830'),
('benyamin', '1234', 'Benyamin Limanto', '0313551830'),
('johan', '123', 'Johan Budi', '0313551830'),
('TEST', 'TEST', 'TEST', 'TEST');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`transkode`,`username`,`kode`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
